<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Wooden_House_Walls_Tilset" tilewidth="16" tileheight="16" tilecount="15" columns="5">
 <image source="../Tileset images/Wooden_House_Walls_Tilset.png" width="80" height="48"/>
</tileset>
