<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="cave_tileset" tilewidth="16" tileheight="16" tilecount="280" columns="20">
 <image source="../Tileset images/cave_tileset.png" width="320" height="224"/>
</tileset>
