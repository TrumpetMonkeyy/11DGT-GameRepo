<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Wooden_House_Roof" tilewidth="16" tileheight="16" tilecount="35" columns="7">
 <image source="../Tileset images/Wooden_House_Roof_Tilset.png" width="112" height="80"/>
</tileset>
