<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Dimensional_Portal" tilewidth="16" tileheight="16" tilecount="24" columns="6">
 <image source="../Tileset images/Dimensional_Portal.png" width="96" height="64"/>
</tileset>
